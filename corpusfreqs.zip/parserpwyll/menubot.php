

<br>
<div class='menu' align='center'>
<a href="index.html"> INDEX</a><b> || </b>
<a href="textopenfile.php"> FULL TEXT: PAGES</a><b> || </b><a href="sentences.php">FULL TEXT: SENTENCES</a><b> || </b><a href="dictext.php">LIST OF UNITS</a><b> || </b><a href="termsfreq.php"> FREQUENCIES </a> 
<b> || </b><a href="termsocurr.php"> OCCURRENCES 
</a>
</div>
